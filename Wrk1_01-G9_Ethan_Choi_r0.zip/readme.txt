
PROJECT TITLE: IoT Bay Web Application

PURPOSE OF PROJECT: Display a rough prototype spike of a proposed IoT Bay
web application

VERSION: Release 0

DATE: 3rd May 2020

AUTHORS: Ethan Choi, 13202799

REQUIREMENTS: Netbeans IDE 8.2, JDK 8


DEPLOY INSTRUCTIONS: 
1. Create a new folder called "IoT Bay Assignment"
2. Within "IoT Bay Assignment", create a new folder called "Web Pages"
3. Extract Wrk1_01-G9_Ethan_Choi.war into "IoT Bay Assignment"
4. Move all .jsp and .css files into the "Web Pages" folder

5. Open NetBeans IDE 8.2
6. Click "File"
7. Click "New Project"
8. Select "Java Web"
9. Select "Web Application from Existing Source"
10. Click "Next"

11. Set "Location" as the path for the "IoT Bay Assignment" folder
12. Click "Next"

13. Ensure that the server is set to "GlassFish Server 4.1.1" and Java EE version is "Java EE 7 Web"
14. Click "Next"

15. Set "Web-INF Contents" to the path for the "WEB-INF" folder in the "IoT Bay Assignment" folder
16. Click "Finish"

17. A warning with "New web proiject with existing sources" will appear. Click "ignore"

The application can now be run in the browser by pressing the green play button in the NetBeans IDE tool bar.


